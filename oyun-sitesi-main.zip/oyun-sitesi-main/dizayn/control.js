const mongoose = require('mongoose');
mongoose.model('posts', new mongoose.Schema({}), 'posts');
const Post = mongoose.model('posts');


exports.Index = (req, res, next) => {
  Post.find()
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/index', {posts,layout: false});
    })
    .catch((err) => {
      res.status(404).send();
    })
};
 
exports.Show = (req, res) => {
  Post.findOne({slug:req.params.slug})
    .then((data) => {
      const post = data.toObject();
      res.render('show', {post});
    })
    .catch((err) => {
      console.log(`Error: ${err.message}`);
      res.status(404).send();
    });
};

exports.KizOyunlari = (req, res) => {
  Post.find({category: 'Kız Oyunları'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/kız', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
exports.YarisOyunlari = (req, res) => {
  Post.find({category: 'Yarış Oyunları'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/yaris', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
exports.MaceraOyunlari = (req, res) => {
  Post.find({category: 'Macera Oyunları'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/macera', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
exports.AksiyonOyunlari = (req, res) => {
  Post.find({category: 'Aksiyon Oyunları'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/aksiyon', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
exports.BeceriOyunlari = (req, res) => {
  Post.find({category: 'Beceri Oyunları'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/beceri', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
exports.ikiKisilikOyunlar = (req, res) => {
  Post.find({category: '2 Kişilik Oyunlar'})
    .sort()
    .lean()
    .then((posts) => {
      res.render('page/2-kisilik', {posts,layout: false});
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send();
    })
};
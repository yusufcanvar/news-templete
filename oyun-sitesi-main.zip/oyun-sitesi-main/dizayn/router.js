const express = require('express');
const Controller = require('./control');
const mongodb_uri = 'mongodb+srv://yusuf:yusuf123@nodeblog.s3snc.mongodb.net/node-blog?retryWrites=true&w=majority'
const router = express.Router();


router.get('/', Controller.Index);
router.get('/oyun/:slug', Controller.Show);


router.get('/kiz-oyunlari', Controller.KizOyunlari);
router.get('/yaris-oyunlari', Controller.YarisOyunlari);
router.get('/macera-oyunlari', Controller.MaceraOyunlari);
router.get('/aksiyon-oyunlari', Controller.AksiyonOyunlari);
router.get('/beceri-oyunlari', Controller.BeceriOyunlari);
router.get('/2-kisilik-oyunlar', Controller.ikiKisilikOyunlar);

router.get('/cdn-cgi/l/email-protection',function(req,res){
    res.status(404).send()
  });

module.exports = router;
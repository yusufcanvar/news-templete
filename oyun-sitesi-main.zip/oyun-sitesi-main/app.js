const express = require('express');
const mongoose = require('mongoose');
const exphbs = require('express-handlebars');
const hbs = require('./dizayn/hbs');

// import mongodb_uri
const mongodb_uri = "mongodb+srv://yusuf:yusuf123@nodeblog.s3snc.mongodb.net/node-blog?retryWrites=true&w=majority"

mongoose.connect(mongodb_uri, {
    useNewUrlParser : true, 
    useUnifiedTopology : true,
    useFindAndModify : false
})
.then(() => {
        console.log(`Connected to MongoDB`);
    })
    .catch((e) => {
        console.log(`Error: ${e.message}`);
    });


// import routes
const posts = require('./dizayn/router');
const { get } = require('http');
const app = express();

// Static files
app.use(express.static(__dirname + '/public'));

// View Engine
app.engine('handlebars', exphbs({
    defaultLayout: 'main',
    helpers: {
        dateString: hbs.dateString,
        getDate: hbs.getDate,
        select: hbs.select,
        toBase64: hbs.toBase64
    }
}));
app.set('view engine', 'handlebars');

// Bodyparser
app.use(express.urlencoded({
    extended: true
}));
app.use(express.json());

// log req method and path
app.use((req, res, next) => {
    console.log(`Req : ${req.method}  ${req.url}`);
    next();
});

// Routes
app.use('/', posts);


//Çalışma Portu
const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`Server started on port ${port}`);
}).on('error', (err) => {
    console.log('\x1b[31m%s\x1b[0m', 'Unable to start the server');
    console.log(`Error: ${err.message}`);
});

